<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>Dashboard - Analytics</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="height=device-height, initial-scale=1">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    

    <style>
        hr { margin-right: 15px; margin-left: 15px; border-color: rgba(255, 255, 255, 0.1); }

        .full-height { height: 100vh; }
        .clean-padding { padding-left: 0; padding-right: 0; }
        .heading { margin: 10px; color: white; }

        #sidebar { background-color: #212121; }
        #applicationName { color: white; font-weight: bold; display: block; background-color: grey; text-align: center; }
        #content { background-color: #F1F8E9; padding-top: 20px; }
        #functionBar { height: 10vh; }
        #navigation a { color: white; display: block; padding: 10px; font-weight: bold; transition: all linear 0.2s 0s; margin-bottom: 0; margin-top: 0;}
        #navigation a > i { margin-right: 10px; }
        #navigation a:hover { background-color: white; color: #4CAF50; text-decoration: none; cursor: pointer; }
        #btnDataValue { width: 100%; margin-left: 30px; margin-right: 30px; background-color: transparent; border-style: none; border-bottom: 1px solid white; color: white; }
        #btnDataValue > span { }
    </style>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.min.js"></script>

</head>

<body class="container-fluid">
    <main class="row">
        <div class="col-md-2 full-height clean-padding"  id="sidebar">
            <div>
                <span class="h4" id="applicationName">Name of Application</span>
            </div>
            <div id="navigation">
                <a class="h4"><i class="glyphicon glyphicon-signal"></i>Analytics</a>
                <a class="h4"><i class="glyphicon glyphicon-list"></i>Data</a>
            </div>
            <hr>
            <div>
                <span class="heading">Showing</span>
            </div>
            <div class="dropdown">
                <button class="dropdown-toggle" type="button" id="btnDataValue" data-toggle="dropdown" aria-hashpopup="true" aria-expanded="true"><b>Carbon Dioxide</b><span class="glyphicon glyphicon-option-vertical"></span></button>
                <ul class="dropdown-menu" aria-labelledby="btnDataValue">
                    <li><a>Temperature</a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-10 full-height" id="content">
            <div><?php echo $carbon->render(); ?></div>
        </div>
    </main>

    <script src="<?php echo e(asset('js/jquery-3.2.1.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    
</body>

</html>